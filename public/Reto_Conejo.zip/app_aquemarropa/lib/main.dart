import 'package:app_aquemarropa/pantallas/top.dart';
import 'package:flutter/material.dart';
import 'pantallas/huevo.dart';
import 'pantallas/perfil.dart';


void main() {
  runApp(Top());
}
