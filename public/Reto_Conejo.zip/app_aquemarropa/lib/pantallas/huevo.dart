import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Huevo extends StatelessWidget {
  Huevo({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(

        backgroundColor: Color(0xFF011f26),

        body: Container(
          child: Column(children: [
        
          SizedBox(height: MediaQuery.of(context).size.height * 0.3),

        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          Text("03D : 12H : 13M", style: GoogleFonts.ibmPlexMono(fontSize:30, color: Color(0xFFffffff), fontWeight: FontWeight.w500)),
        ],),

        SizedBox(height: 20),


        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
        Container(
          height: MediaQuery.of(context).size.height * 0.25,
          width: MediaQuery.of(context).size.width * 0.7,
          decoration: BoxDecoration(
            color: Color(0xFFf23d6d),
            image: DecorationImage(
              image: AssetImage('assets/images/HUEVO.png'),
              ),
              borderRadius: BorderRadius.all(

              Radius.circular(5) 

              )
          ),
        ),
        ],),
          ],)
        ),
      ),
    );
}
}