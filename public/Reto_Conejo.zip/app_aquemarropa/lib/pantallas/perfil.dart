// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';


class Perfil extends StatelessWidget {
  Perfil({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color(0xFF011f26),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 50.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 50),
                Center(
                  child: CircularProfileAvatar(
                    'https://avatars0.githubusercontent.com/u/8264639?s=460&v=4',
                    radius: 50,
                    backgroundColor: Colors.transparent,
                    borderWidth: 2,
                    borderColor: Color(0xFFf23d6d),
                    elevation: 5.0,
                    foregroundColor: Color(0xFFf23d6d).withOpacity(0.1),
                    cacheImage: true,
                    imageFit: BoxFit.cover,
                    onTap: () {
                      print('adil');
                    },
                    showInitialTextAbovePicture: true,
                  ),
                ),

                SizedBox(height: 40),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Text(
                      'Creativo 1',
                      style: GoogleFonts.ibmPlexMono(
                          fontSize: 25,
                          color: Color(0xFFf23d6d),
                          fontWeight: FontWeight.w700),
                    ),
                    Text(
                      '@elartistaquees',
                      style: GoogleFonts.ibmPlexMono(
                          fontSize: 12,
                          color: Color(0xFFffffff),
                          fontWeight: FontWeight.w500),
                    ),
                  ],
                ),

                SizedBox(height: 10),

                Text(
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et olore magna aliqua. Ut enim ad minim veniam.',
                  style: GoogleFonts.ibmPlexMono(
                      fontSize: 10,
                      color: Color(0xFFffffff),
                      fontWeight: FontWeight.w500,
                      height: 2.0),
                ),

                SizedBox(height: 20),

               Row(
                children: [
                  Text(
                    'Trofeos',
                    style: GoogleFonts.ibmPlexMono(
                      fontSize: 18,
                      color: Color(0xFFf23d6d),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: 16),
                      child: Divider(
                        color: Color(0xFFf23d6d),
                        thickness: 1,
                      ),
                    ),
                  ),
                ],
              ),

                SizedBox(height: 20),

                Container(
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.center,
                  child: SizedBox(
                    height: 50,
                    child: ListView.builder(
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        return Container(
                          margin: EdgeInsets.only(left: 25),
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                              color: Color(0xFF2f474d),
                              borderRadius: BorderRadius.circular(100)),
                        );
                      },
                    ),
                  ),
                ),

                SizedBox(height: 20),

                Row(
                children: [
                  Text(
                    'Insignias',
                    style: GoogleFonts.ibmPlexMono(
                      fontSize: 18,
                      color: Color(0xFFf23d6d),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: 16),
                      child: Divider(
                        color: Color(0xFFf23d6d),
                        thickness: 1,
                      ),
                    ),
                  ),
                ],
              ),

                SizedBox(height: 20),

                Container(
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.center,
                  child: SizedBox(
                    height: 50,
                    child: ListView.builder(
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        return Container(
                          margin: EdgeInsets.only(left: 25),
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                              color: Color(0xFF2f474d),
                              borderRadius: BorderRadius.circular(100)),
                        );
                      },
                    ),
                  ),
                ),

                SizedBox(height: 20),

                  Row(
                children: [
                  Text(
                    'Posts',
                    style: GoogleFonts.ibmPlexMono(
                      fontSize: 18,
                      color: Color(0xFFf23d6d),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: 16),
                      child: Divider(
                        color: Color(0xFFf23d6d),
                        thickness: 1,
                      ),
                    ),
                  ),
                ],
              ),

                SizedBox(height: 25),
            
                Container(
                child: GridView.count(
                  mainAxisSpacing: 20.0,
                  crossAxisSpacing: 20.0,
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  children: List.generate(8, (index) {
                    return Container(
                        decoration: BoxDecoration(
                        color: Color(0xFF2f474d), // Color de fondo del contenedor
                        borderRadius: BorderRadius.circular(5.0), // Radio de las esquinas
                      ),
                    );
                  }),
                ),
                ),

                SizedBox(height: 20),

              ],
            ),
          ),
        ),
      ),
    );
  }
}