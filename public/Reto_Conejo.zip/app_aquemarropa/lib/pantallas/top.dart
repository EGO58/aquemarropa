// ignore_for_file: prefer_const_constructors

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:accordion/accordion.dart';
import 'package:accordion/controllers.dart';
import 'package:google_fonts/google_fonts.dart';

class Top extends StatelessWidget {
  const Top({super.key});

   @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const AccordionPage(),
    );
  }
}

class AccordionPage extends StatelessWidget {
  const AccordionPage({super.key});


  static const contentStyle = TextStyle(
      color: Color(0xff999999), fontSize: 14, fontWeight: FontWeight.normal);
  static const loremIpsum =
      '''Lorem ipsum is typically a corrupted version of 'De finibus bonorum et malorum', a 1st century BC text by the Roman statesman and philosopher Cicero, with words altered, added, and removed to make it nonsensical and improper Latin.''';
  static const slogan =
      'Do not forget to play around with all sorts of colors, backgrounds, borders, etc.';


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF011f26),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 30.0),

        child: Accordion(
          headerBackgroundColor: Color(0xFFf23d6d),
          headerBorderColor: Color(0xFFffffff),
          headerBorderColorOpened: Color.fromARGB(0, 255, 255, 255),
          headerBorderWidth: 1,// headerBorderWidth: 1,
          headerBackgroundColorOpened: Color(0xFFf23d6d),
          contentBackgroundColor: Color(0xFFf23d6d),
          contentBorderColor: Color(0xFFf23d6d),
          contentBorderWidth: 0,
          contentHorizontalPadding: 20,
          headerBorderRadius: 5,
          scaleWhenAnimating: false,
          openAndCloseAnimation: true,
          headerPadding:
              const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          sectionOpeningHapticFeedback: SectionHapticFeedback.heavy,
          sectionClosingHapticFeedback: SectionHapticFeedback.light,
          children: [
            AccordionSection(
              isOpen: true,
            
                header: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween, // Alineamos los elementos al inicio y al final del espacio disponible
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Una pascua',
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: 20,
                            color: Color(0xFFffffff),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          'muy EGGS-pecial',
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: 20,
                            color: Color(0xFFffffff),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                    width: MediaQuery.of(context).size.height * 0.15,
                    height: MediaQuery.of(context).size.width * 0.15,
                    child: Padding(
                      padding: EdgeInsets.only(right: 30.0),
                      child: 
                    Image.asset('assets/images/CONEJO.png', 
                    
                    fit: BoxFit.contain),
                    ),
                    ),
                  ],
                ),
              contentVerticalPadding: 15,
              content: Image.asset(
                'assets/images/TOP.png',
                scale: 0.15,
                ),
            ),
            AccordionSection(
              isOpen: true,
            
                header: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween, // Alineamos los elementos al inicio y al final del espacio disponible
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Lo que sea',
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: 20,
                            color: Color(0xFFffffff),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          'el reto O2',
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: 20,
                            color: Color(0xFFffffff),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                    width: MediaQuery.of(context).size.height * 0.15,
                    height: MediaQuery.of(context).size.width * 0.15,
                    child: Padding(
                      padding: EdgeInsets.only(right: 30.0),
                      child: 
                    Image.asset('assets/images/CONEJO.png', 
                    
                    fit: BoxFit.contain),
                    ),
                    ),
                  ],
                ),
              contentVerticalPadding: 15,
              content: Image.asset(
                'assets/images/TOP.png',
                scale: 0.15,
                ),
            ),
            AccordionSection(
              isOpen: true,
            
                header: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween, // Alineamos los elementos al inicio y al final del espacio disponible
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Lo que sea',
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: 20,
                            color: Color(0xFFffffff),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          'el reto O3',
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: 20,
                            color: Color(0xFFffffff),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                    width: MediaQuery.of(context).size.height * 0.15,
                    height: MediaQuery.of(context).size.width * 0.15,
                    child: Padding(
                      padding: EdgeInsets.only(right: 30.0),
                      child: 
                    Image.asset('assets/images/CONEJO.png', 
                    
                    fit: BoxFit.contain),
                    ),
                    ),
                  ],
                ),
              contentVerticalPadding: 15,
              content: Image.asset(
                'assets/images/TOP.png',
                scale: 0.15,
                ),
            ),
            
    
          ],
        ),
      ),
      );
}
}